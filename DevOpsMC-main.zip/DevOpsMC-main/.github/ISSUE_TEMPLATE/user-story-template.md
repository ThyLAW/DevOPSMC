---
name: User Story Template
about: Template for a user story
title: New User Story
labels: user story
assignees: ''

---

User story purpose

Focus on the objective for a specific role and the motivation for it.

This should be non-technical language focused on the value.

What is acceptance criteria
- [ ] Criteria 1
- [ ] Criteria 2
